FINANCE DASHBOARD ANDROID APP

Phone-first version of your existing Finance Dashboard V8.
The existing finance features and local autosave are retained. A mobile bottom navigation bar has been added for Home, Summary, Activity, Insights and Forecast.

BUILD THE APK USING ONLY YOUR PHONE (GitHub Actions)
1. On your phone, open github.com and sign in (create a free account if needed).
2. Create a NEW PUBLIC or PRIVATE repository, e.g. finance-dashboard-android.
3. Upload the CONTENTS of this ZIP into the repository (not the ZIP file itself). Keep the .github/workflows/build-apk.yml file and folder structure.
4. Open the repository's Actions tab. If prompted, enable workflows.
5. Select "Build Android APK" then "Run workflow".
6. Wait for the run to finish successfully. Open that run and download the "Finance-Dashboard-APK" artifact.
7. Extract the downloaded artifact ZIP on your phone, tap app-debug.apk, and allow installation from your browser/files app if Android asks.

NOTES
- This is a debug APK suitable for personal installation/testing, not a Play Store release.
- Data is stored locally by the app. Keep using the app on the same installation and export backups regularly from its backup feature.
- No login or cloud sync is added.
